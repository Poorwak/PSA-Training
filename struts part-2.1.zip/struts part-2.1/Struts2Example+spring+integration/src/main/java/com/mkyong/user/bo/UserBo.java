package com.mkyong.user.bo;

public interface UserBo{

	public void printUser();
	
}