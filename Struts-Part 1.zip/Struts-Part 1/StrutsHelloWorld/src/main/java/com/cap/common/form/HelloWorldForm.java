package com.cap.common.form;

import org.apache.struts.action.ActionForm;

public class HelloWorldForm extends ActionForm{
	
	String message;
	String newmessage;

	public String getNewmessage() {
		return newmessage;
	}

	public void setNewmessage(String newmessage) {
		this.newmessage = newmessage;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}