package com.cap.actions;

import com.opensymphony.xwork2.Action;
//URL --http://localhost:8080/Struts2Form/student.action

public class TeacherAction implements Action {

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	private String salary;
	private String experience;

	public String execute() {

		return Action.SUCCESS;

	}

}
