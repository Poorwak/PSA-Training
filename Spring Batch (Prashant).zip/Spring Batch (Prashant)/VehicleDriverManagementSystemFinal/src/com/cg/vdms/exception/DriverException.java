package com.cg.vdms.exception;

public class DriverException extends Exception
{
	public DriverException()
	{
		super();
	}
	public DriverException(String message)
	{
		super(message);
	}
}
