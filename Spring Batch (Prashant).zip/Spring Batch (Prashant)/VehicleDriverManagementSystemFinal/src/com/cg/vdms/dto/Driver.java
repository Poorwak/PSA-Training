package com.cg.vdms.dto;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="Driver")
public class Driver 
{
	@Id
	@Column(name="driver_id")
	private Integer driverId;
	
	@Column(name="fname")
	@NotNull(message="First Name can't be Empty")
	private String fname;
	
	@Column(name="lname")
	@NotNull(message="Last Name should not be empty")
	private String lname;
	
	@Column(name="phone_no")
	@NotNull(message="Phone number should not be empty")
	@Max(10)
	private Double phn;
	
	@Column(name="email")
	private String email;
	
	@Column(name="password")
	private String password;
	
	@Column(name="date_of_joining")
	private Date doj;
	
	@Column(name="admin")
	private String admin;
	
	@ManyToMany	
	private List<Vehicle> vehicleList = new ArrayList();

	public List<Vehicle> getVehicleList() {
		return vehicleList;
	}

	public void setVehicleList(List<Vehicle> vehicleList) {
		this.vehicleList = vehicleList;
	}

	public Integer getDriverId() 
	{
		return driverId;
	}

	public void setDriverId(Integer driverId)
	{
		this.driverId = driverId;
	}

	public String getFname()
	{
		return fname;
	}

	public void setFname(String fname)
	{
		this.fname = fname;
	}

	public String getLname()
	{
		return lname;
	}

	public void setLname(String lname)
	{
		this.lname = lname;
	}

	public Double getPhn()
	{
		return phn;
	}

	public void setPhn(Double phn)
	{
		this.phn = phn;
	}

	public String getEmail()
	{
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}


	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	@Override
	public String toString() {
		return "Driver [driverId=" + driverId + ", fname=" + fname + ", lname=" + lname + ", phn=" + phn + ", email="
				+ email + ", password=" + password + ", doj=" + doj + ", admin=" + admin + "]";
	}
	
	
}
