package com.cg.vdms.dao;

import java.util.List;

import com.cg.vdms.dto.Driver;
import com.cg.vdms.dto.Vehicle;
import com.cg.vdms.exception.DriverException;

public interface IVdmsDao 
{
	public List <String> getAllEmail();
	public List<String>getAllPass();
	
	public String addDriver(Driver driver)throws DriverException;
	public String addVehicle(Vehicle vehicle);
	
	public Vehicle VehicleInfo(Integer vehicleId) throws DriverException;
	public Driver DriverInfo(Integer driveId) throws DriverException;
	
	public Driver loginDriver(String email, String password) throws DriverException;
	
	public void updateDriver(Driver driver);
	public void updateDriverContact(Double driverNum, Integer id);
	public void updateVehicleColor(Integer id, String color);
	
}
