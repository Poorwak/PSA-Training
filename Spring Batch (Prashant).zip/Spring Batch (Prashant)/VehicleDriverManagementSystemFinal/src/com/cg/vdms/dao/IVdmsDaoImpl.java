package com.cg.vdms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.vdms.dto.Driver;
import com.cg.vdms.dto.Vehicle;
import com.cg.vdms.exception.DriverException;

@Repository("IVdmsdao")
public class IVdmsDaoImpl implements IVdmsDao
{

	Connection conn = null;
	PreparedStatement pst = null;
	Statement st = null;
	ResultSet rs = null;
	
	@PersistenceContext
	EntityManager em;

	
	@Override
	public String addDriver(Driver driver) throws DriverException 
	{
		//System.out.println("driver value inside daoImpl : " + driver.toString());
		em.persist(driver);
		em.flush();
		return String.valueOf(driver.getDriverId());
	}
	
	@Override
	public Driver loginDriver(String email,String password) throws DriverException 
	{
		Query query;
		try{
			query=em.createQuery("SELECT driver FROM Driver driver WHERE driver.email=:em "
					+ "AND driver.password=:pass");
			query.setParameter("em",email);
			query.setParameter("pass",password);

			return (Driver) query.getSingleResult();
		}
		catch(Exception d){
			throw new DriverException("Invalid credentials!");
		}
	}
	
	@Override
	public List<String> getAllEmail() 
	{
		Query emQuery=em.createQuery("SELECT email FROM Driver");
		return emQuery.getResultList();
	}
	@Override
	public List<String> getAllPass() 
	{
		Query querytwo=em.createQuery("SELECT password FROM Driver");
		return querytwo.getResultList();
	}

	@Override
	public String addVehicle(Vehicle vehicle) {
		
		em.persist(vehicle);
		em.flush();
		return String.valueOf(vehicle.getVehicleId());
	}

	@Override
	public Vehicle VehicleInfo(Integer vehicleId) throws DriverException {
		try{
			Query fetchQuery=em.createQuery("SELECT vehicle FROM Vehicle vehicle WHERE vehicle.vehicleId=:vId");
			fetchQuery.setParameter("vId", vehicleId);
			return  (Vehicle) fetchQuery.getSingleResult();
		}
		catch(Exception e){
			throw new DriverException("Invalid Id");
		}
	}

	@Override
	public Driver DriverInfo(Integer driveId) throws DriverException {
		try{
			Query query=em.createQuery("SELECT driver FROM Driver driver WHERE driver.driverId=:id");
			query.setParameter("id",driveId);
			
			return (Driver)query.getSingleResult();
		}
		catch(Exception e){
			throw new DriverException("Invalid Id");
		}
		
	}

	@Override
	public void updateDriver(Driver driver) {
		em.merge(driver);
		em.flush();
//		Query updateQry=em.createQuery("UPDATE Driver d SET d.fname=:fn,d.lname=:ln,"
//				+ "d.phn=:p, d.email=:e, d.password=:pass, d.doj=:do WHERE d.driverId=:did ");
//		
//		System.out.println("driver object" + driver.toString());
//		
////		Query updateQry=em.createQuery("UPDATE Driver d SET d.fname=:fn,"
////				+ " WHERE d.driverId=:did ");
////		
//		updateQry.setParameter("fn",driver.getFname());
//		updateQry.setParameter("ln",driver.getLname());
//		updateQry.setParameter("p",driver.getPhn());
//		updateQry.setParameter("e",driver.getEmail());
//		updateQry.setParameter("pass",driver.getPassword());
//		updateQry.setParameter("do",driver.getDoj());
//		updateQry.setParameter("did",driver.getDriverId());
//		updateQry.executeUpdate();		
	}

	@Override
	public void updateDriverContact(Double driverNum, Integer id) {
		Query updateQry=em.createQuery("UPDATE Driver d SET d.phn=:ph WHERE d.driverId=:did ");
		
		System.out.println("inside update.." + id + " " + driverNum);
		
		updateQry.setParameter("ph",driverNum);
		updateQry.setParameter("did",id);
		
		updateQry.executeUpdate();
		
	}

	@Override
	public void updateVehicleColor(Integer id, String color) {
		Query updateQry=em.createQuery("UPDATE Vehicle v SET v.color=:co WHERE v.vehicleId=:vid ");
		
		updateQry.setParameter("co",color);
		updateQry.setParameter("vid",id);
		
		updateQry.executeUpdate();
		
	}
	
}
