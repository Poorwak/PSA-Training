package com.cg.vdms.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.vdms.dto.Driver;
import com.cg.vdms.dto.Vehicle;
import com.cg.vdms.exception.DriverException;
import com.cg.vdms.service.IVdmsService;

@Controller
public class VehicleController {

	@Autowired IVdmsService vdmsService;
	
	@RequestMapping(value="veh")
	public String vehicleOptions()
	{
		System.out.println("in vehicle");
		return "VehicleOptions";
	}
	
	@RequestMapping(value="addvehicle", method=RequestMethod.GET)
	public String addVehicle(@ModelAttribute("veh")Vehicle vehicle)
	{
		return "AddVehicle";
	}
	
	@RequestMapping(value="insertVehData",method=RequestMethod.POST)
	public ModelAndView addVehicleInfo(@ModelAttribute("veh")Vehicle vehicle, BindingResult result) throws DriverException
	{
		System.out.println("Driver values" + vehicle.toString());
		String dId = vdmsService.addVehicle(vehicle);
		if(dId != null)
			return new ModelAndView("success", "msg", "Successfully Inserted");
		else
			return new ModelAndView("Error","msg","Insertion faliure");
	}
	
	@RequestMapping(value="getvehicleInfo", method=RequestMethod.GET)
	public String getVehicleId()
	{
		return "InputVehicleId";
	}
	
	@RequestMapping(value="getvehicle", method=RequestMethod.POST)
	public ModelAndView getvehicleInfo(@RequestParam("id") Integer vehicleId)
	{
		System.out.println("vehicle id" + vehicleId);
		
		Vehicle v = null;
		try {
			v = vdmsService.VehicleInfo(vehicleId);
			return new ModelAndView("VehicleInfo","vehicle",v);
		} catch (DriverException e) {
			e.printStackTrace();
			return new ModelAndView("InputVehicleId","msg",e.getMessage());
		}	
	}
	
	@RequestMapping(value="updatecolor")
	public ModelAndView updateColor(@RequestParam("vid") String vehicleId, HttpServletRequest request)
	{
		request.getSession(true).setAttribute("uid", vehicleId);
		return new ModelAndView("UpdateVehicleColor");
	}
	
	@RequestMapping(value="vehicleupdated")
	public ModelAndView vehicleUpdated(@RequestParam("color") String color, HttpServletRequest request )
	{
		String id = (String) request.getSession(false).getAttribute("uid");
//		System.out.println("driver id inside session" + id + " " + driverNum);
		int vId = Integer.valueOf(id);
		vdmsService.updateVehicleColor(vId, color);
		return new ModelAndView("success", "msg", "Successfully Updated");
	}
	
	
}
